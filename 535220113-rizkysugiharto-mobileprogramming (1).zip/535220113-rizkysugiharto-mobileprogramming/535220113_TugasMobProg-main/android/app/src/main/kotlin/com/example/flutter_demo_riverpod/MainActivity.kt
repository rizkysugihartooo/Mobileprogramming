package com.example.flutter_demo_riverpod

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
